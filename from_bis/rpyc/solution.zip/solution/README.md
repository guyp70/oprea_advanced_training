This is a simple RPyC example.
This does not include the advanced requirements, nor tests.