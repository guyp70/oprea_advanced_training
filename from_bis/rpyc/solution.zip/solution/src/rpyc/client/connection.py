import requests

from rpyc.common.consts import VALUE_KEY, TYPE_KEY, PROXY_TYPE_STR
from .consts import IMPORT_URL, SERVER_URL
from .proxy import Proxy


class ModuleInitializer(object):
    def __init__(self, connection):
        """
        :param connection: The server connection object.
        :type connection: RemoteControlConnection
        """
        self.connection = connection

    def __getattr__(self, item):
        """
        Get the remote module's attribute.

        :type item: str
        :rtype: Proxy | str | bool | float | int | types.NoneType
        """
        response_data = self.connection.get_json_from_remote(IMPORT_URL.format(module=item))
        return Proxy(connection=self.connection, _id=response_data[VALUE_KEY])


class RemoteControlConnection(object):
    def __init__(self, ip, port):
        self.ip = ip
        self.port = port
        self.modules = ModuleInitializer(connection=self)

    def get_json_from_remote(self, url, params=None):
        """
        Get a JSON object (dict) by calling the given URL with the given parameters using the GET method.

        :type url: str
        :type params: dict
        :rtype: dict
        """
        response = requests.get(SERVER_URL.format(server=self.ip, port=self.port, url=url), params=params)
        return response.json()

    def post_json_from_remote(self, url, data=None):
        """
        Get a JSON object (dict) by calling the given URL with the given json using the POST method.

        :type url: str
        :type data: dict
        :rtype: dict
        """
        response = requests.post(SERVER_URL.format(server=self.ip, port=self.port, url=url), json=data)
        return response.json()

    def extract_data_from_response_data(self, response_data):
        """
        Get the relevant data from the JSON response - either Proxy or the value.

        :type response_data: dict
        :rtype: Proxy | str | bool | float | int | types.NoneType
        """
        if response_data[TYPE_KEY] == PROXY_TYPE_STR:
            return Proxy(self, response_data[VALUE_KEY])
        return response_data[VALUE_KEY]
