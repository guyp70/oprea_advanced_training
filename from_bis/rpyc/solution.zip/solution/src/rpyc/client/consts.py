SERVER_URL = 'http://{server}:{port}{url}'
# API calls
IMPORT_URL = '/api/import/{module}'
CALL_URL = '/api/call/{id}'
GETATTR_URL = '/api/getattr/{id}/{attribute}'
