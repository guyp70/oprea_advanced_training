from .consts import CALL_URL, GETATTR_URL


class Proxy(object):
    def __init__(self, connection, _id):
        """
        :param connection: The server connection object.
        :type connection: rpyc.RemoteControlConnection
        :param _id: The id of the original object in the server
        :type _id: int
        """
        self.connection = connection
        self._id = _id

    def __getattr__(self, item):
        """
        Get the remote object's attribute.

        :type item: str
        :rtype: Proxy | str | bool | long | int | types.NoneType
        """
        response_data = self.connection.get_json_from_remote(GETATTR_URL.format(id=self._id, attribute=item))
        return self.connection.extract_data_from_response_data(response_data=response_data)

    def __call__(self, *args, **kwargs):
        """
        Call the remote function with args and kwargs and return the result.

        :rtype: Proxy | str | bool | long | int | types.NoneType
        """
        response_data = self.connection.post_json_from_remote(CALL_URL.format(id=self._id),
                                                              data=dict(args=args, kwargs=kwargs))
        return self.connection.extract_data_from_response_data(response_data=response_data)
