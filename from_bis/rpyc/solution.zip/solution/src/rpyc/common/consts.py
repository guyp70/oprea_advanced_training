PROXY_TYPE_STR = 'proxy'
VALUE_KEY = 'value'
TYPE_KEY = 'type'
