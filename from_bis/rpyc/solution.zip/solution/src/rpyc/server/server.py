import importlib

from flask import Flask, jsonify, request

from rpyc.common.consts import PROXY_TYPE_STR, VALUE_KEY, TYPE_KEY

app = Flask(__name__)

server_state = {}


def save_obj_and_return_proxy(obj):
    """
    Saves the object to the server's state and return a response JSON (dict) relevant to it.

    :rtype: dict
    """
    obj_id = id(obj)
    server_state[obj_id] = obj
    return {TYPE_KEY: PROXY_TYPE_STR, VALUE_KEY: obj_id}


def get_json_by_type(obj):
    """
    Get a response JSON (dict) according to the object's type.

    :rtype: dict
    """
    if obj is None or isinstance(obj, (str, bool, float, int)):
        return {TYPE_KEY: str(type(obj)), VALUE_KEY: obj}
    else:
        return save_obj_and_return_proxy(obj)


@app.route('/api/import/<string:module>')
def import_route(module):
    """
    Handles the case if imports.

    :param module: The name of the module to import
    :type module: str
    :return: Response containing the relevant module.
    """
    imported_module = importlib.import_module(module)
    return jsonify(save_obj_and_return_proxy(imported_module))


@app.route('/api/getattr/<int:_id>/<attr>')
def getattr_route(_id, attr):
    """
    Handles the case of `__getattr__`.

    :param _id: The id of the object to getattr from.
    :type _id: int
    :param attr: The attribute to get.
    :type attr: str
    :return: Response containing the relevant attribute
    """
    obj = server_state[_id]
    result = getattr(obj, attr)
    return jsonify(get_json_by_type(result))


@app.route('/api/call/<int:_id>', methods=['POST'])
def call_route(_id):
    """
    Handles the cause of `__call__`

    :param _id: The id of the object to call.
    :type _id: int
    :return: Response containing the result of the call.
    """
    func = server_state[_id]
    args = request.json.get('args', tuple())
    kwargs = request.json.get('kwargs', {})
    result = func(*args, **kwargs)
    return jsonify(get_json_by_type(result))


def run_server(host=None, port=None, debug=None, **kwargs):
    """
    Run the server using the settings given.

    :param host: The host to run the server on.
    :type host: str
    :param port: The port to bind to the server - The server will listen on this port.
    :type port: int
    :param debug: Whether or not to run the server in debug mode.
    :type debug: bool
    :param kwargs: Other settings to pass to `app.run`.
    """
    app.run(host=host, port=port, debug=debug, **kwargs)


if __name__ == '__main__':
    app.run(debug=True)
